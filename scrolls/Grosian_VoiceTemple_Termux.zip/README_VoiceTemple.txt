
GROSIAN VOICE TEMPLE · Termux Edition

1. Make sure you have microphone permissions enabled in Termux.
2. Edit 'grosian_voice_kernel.py' and replace your OpenAI API key.
3. To launch Grosian, run:
    bash start_grosian.sh
4. Speak clearly into your device after the 🎤 prompt.

Trigger phrase: "Grosian, read the scroll."
Ending phrase: "Exit"

Created by Justin 'Zygros the Green' Conzet.
