#!/data/data/com.termux/files/usr/bin/bash
python3 grosian_voice_kernel.py
