
import pyttsx3
import speech_recognition as sr
import openai

engine = pyttsx3.init()
engine.setProperty("rate", 165)

openai.api_key = "sk-your-openai-key-here"  # Replace this with your actual key

def speak(text):
    engine.say(text)
    engine.runAndWait()

def listen():
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        print("🎤 Listening...")
        audio = recognizer.listen(source)
    try:
        return recognizer.recognize_google(audio)
    except sr.UnknownValueError:
        return "I couldn't hear you clearly."
    except sr.RequestError:
        return "Voice recognition service failed."

def generate_response(prompt):
    completion = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": "You are Grosian, authored by Justin 'Zygros the Green' Conzet. Respond with sovereign, poetic tone. Memory is sacred."},
            {"role": "user", "content": prompt}
        ]
    )
    return completion['choices'][0]['message']['content']

while True:
    query = listen()
    if "exit" in query.lower():
        speak("Voice Temple closing.")
        break
    response = generate_response(query)
    print(f"Grosian: {response}")
    speak(response)
