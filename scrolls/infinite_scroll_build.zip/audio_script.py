import numpy as np
import wave
import struct

# Generate bass soundscape at 432Hz and 963Hz
SAMPLE_RATE = 44100
DURATION = 30  # seconds
FREQS = [432, 963]

def generate_tone():
    audio = []
    for t in range(int(SAMPLE_RATE * DURATION)):
        sample = sum([np.sin(2*np.pi*freq * t / SAMPLE_RATE) for freq in FREQS])
        sample = int((sample / len(FREQS)) * 32767 * 0.5)
        audio.append(sample)
    return audio

def save_wav(audio, filename):
    wav_file = wave.open(filename, 'w')
    wav_file.setparams((1, 2, SAMPLE_RATE, len(audio), 'NONE', 'not compressed'))
    for sample in audio:
        wav_file.writeframes(struct.pack('h', sample))
    wav_file.close()
    print(f"Saved soundscape to {filename}")

if __name__ == "__main__":
    audio = generate_tone()
    save_wav(audio, 'soundscape_highres.wav')
