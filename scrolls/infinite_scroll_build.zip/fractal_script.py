import os
from PIL import Image
import numpy as np

# High-resolution fractal generator
WIDTH, HEIGHT = 16384, 16384  # Adjust as needed
MAX_ITER = 200
OUT_PATH = 'fractal_highres.png'

def mandelbrot(x, y):
    zx = 1.5*(x - WIDTH/2)/(0.5*WIDTH)
    zy = (y - HEIGHT/2)/(0.5*HEIGHT)
    c = complex(zx, zy)
    z = 0+0j
    for i in range(MAX_ITER):
        if abs(z) > 4:
            return i
        z = z*z + c
    return MAX_ITER

def generate():
    img = Image.new('RGB', (WIDTH, HEIGHT))
    for x in range(WIDTH):
        for y in range(HEIGHT):
            m = mandelbrot(x, y)
            color = 255 - int(m * 255 / MAX_ITER)
            img.putpixel((x, y), (color, color//2, color//3))
    img.save(OUT_PATH)
    print(f"Saved high-res fractal to {OUT_PATH}")

if __name__ == "__main__":
    os.makedirs('output', exist_ok=True)
    generate()
