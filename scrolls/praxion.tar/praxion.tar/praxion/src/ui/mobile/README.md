# Praxion UI - Mobile

This directory contains the mobile UI implementation for Praxion using React Native with Expo.

## Project Structure

```
src/ui/mobile/
├── assets/         # Static assets
├── src/            # React Native source code
│   ├── components/ # UI components
│   ├── hooks/      # Custom React hooks
│   ├── screens/    # Screen components
│   ├── App.jsx     # Main application component
│   └── styles.js   # Global styles
├── package.json    # Dependencies and scripts
├── app.json        # Expo configuration
└── babel.config.js # Babel configuration
```

## Getting Started

```bash
# Install dependencies
yarn install

# Start Expo development server
expo start

# Run on iOS
expo run:ios

# Run on Android
expo run:android
```
