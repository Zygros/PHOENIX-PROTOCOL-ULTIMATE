import React, { useState, useEffect } from 'react';
import { View, TouchableOpacity, Text, StyleSheet } from 'react-native';
import axios from 'axios';

const VoiceControl = ({ onTranscription }) => {
  const [isRecording, setIsRecording] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);

  const startRecording = async () => {
    setIsRecording(true);
    // In a real implementation, this would use the device's microphone
    // For this stub, we'll simulate recording and return a fixed response
    
    setTimeout(() => {
      stopRecording();
    }, 2000); // Simulate 2 seconds of recording
  };

  const stopRecording = async () => {
    setIsRecording(false);
    setIsProcessing(true);
    
    // Simulate processing the audio
    setTimeout(() => {
      // Simulate a transcription result
      const transcription = "Hello Praxion, how are you today?";
      onTranscription(transcription);
      setIsProcessing(false);
    }, 1000);
  };

  return (
    <View style={styles.container}>
      <TouchableOpacity
        style={[
          styles.recordButton,
          isRecording ? styles.recordingActive : null,
          isProcessing ? styles.processingActive : null
        ]}
        onPress={isRecording ? stopRecording : startRecording}
        disabled={isProcessing}
      >
        <Text style={styles.buttonText}>
          {isRecording ? 'Stop' : isProcessing ? 'Processing...' : 'Voice Input'}
        </Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    marginVertical: 10,
  },
  recordButton: {
    backgroundColor: '#3498db',
    borderRadius: 30,
    width: 60,
    height: 60,
    justifyContent: 'center',
    alignItems: 'center',
  },
  recordingActive: {
    backgroundColor: '#e74c3c',
  },
  processingActive: {
    backgroundColor: '#f39c12',
  },
  buttonText: {
    color: 'white',
    fontSize: 12,
    textAlign: 'center',
  },
});

export default VoiceControl;
