import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, FlatList, SafeAreaView, ActivityIndicator } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import axios from 'axios';
import VoiceControl from './components/VoiceControl';

// Message component for chat bubbles
const ChatMessage = ({ message, isUser }) => (
  <View style={[styles.messageContainer, isUser ? styles.userMessage : styles.assistantMessage]}>
    <View style={[styles.messageAvatar, isUser ? styles.userAvatar : styles.assistantAvatar]}>
      <Text>{isUser ? '👤' : '🤖'}</Text>
    </View>
    <View style={[styles.messageContent, isUser ? styles.userContent : styles.assistantContent]}>
      <Text style={[styles.messageText, isUser ? styles.userText : styles.assistantText]}>
        {message}
      </Text>
    </View>
  </View>
);

// Header component
const Header = ({ welcomeMessage }) => (
  <View style={styles.header}>
    <View style={styles.logoContainer}>
      <View style={styles.logo}>
        <Text style={styles.logoText}>P</Text>
      </View>
      <Text style={styles.title}>Praxion</Text>
    </View>
    <Text style={styles.welcomeMessage}>{welcomeMessage}</Text>
  </View>
);

export default function App() {
  const [welcomeMessage, setWelcomeMessage] = useState('Loading...');
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    // Fetch the welcome message on component mount
    fetchWelcomeMessage();
  }, []);

  const fetchWelcomeMessage = async () => {
    try {
      // Note: In a real app, you'd use the device's local IP or a real API endpoint
      const res = await axios.get('http://10.0.2.2:8000/');
      setWelcomeMessage(res.data.message);
    } catch (err) {
      console.error('Error fetching welcome message:', err);
      setWelcomeMessage('Error connecting to Praxion backend');
    }
  };

  const handleSubmit = async () => {
    if (!input.trim()) return;

    // Add user message to chat
    const userMessage = input;
    setMessages(prev => [...prev, { text: userMessage, isUser: true }]);
    setInput('');
    setIsLoading(true);

    try {
      // Note: In a real app, you'd use the device's local IP or a real API endpoint
      const res = await axios.post('http://10.0.2.2:8000/chat', null, {
        params: { message: userMessage }
      });
      
      // Add assistant response to chat
      setMessages(prev => [...prev, { text: res.data.response, isUser: false }]);
    } catch (err) {
      console.error('Error sending message:', err);
      setMessages(prev => [...prev, { 
        text: 'Sorry, I encountered an error processing your request.', 
        isUser: false 
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleVoiceInput = (transcription) => {
    // Set the transcribed text as input
    setInput(transcription);
    
    // Optionally, automatically submit after voice input
    setTimeout(() => {
      handleSubmit();
    }, 500);
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="auto" />
      
      <Header welcomeMessage={welcomeMessage} />
      
      <View style={styles.chatContainer}>
        {messages.length === 0 ? (
          <View style={styles.emptyState}>
            <Text style={styles.emptyStateText}>Start a conversation with Praxion</Text>
          </View>
        ) : (
          <FlatList
            data={messages}
            renderItem={({ item }) => (
              <ChatMessage message={item.text} isUser={item.isUser} />
            )}
            keyExtractor={(_, index) => index.toString()}
            contentContainerStyle={styles.messagesList}
          />
        )}
      </View>
      
      <View style={styles.voiceControlContainer}>
        <VoiceControl onTranscription={handleVoiceInput} />
      </View>
      
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          value={input}
          onChangeText={setInput}
          placeholder="Type a message..."
          placeholderTextColor="#999"
          editable={!isLoading}
        />
        <TouchableOpacity 
          style={[styles.button, isLoading && styles.buttonDisabled]} 
          onPress={handleSubmit}
          disabled={isLoading}
        >
          {isLoading ? (
            <ActivityIndicator color="#fff" size="small" />
          ) : (
            <Text style={styles.buttonText}>Send</Text>
          )}
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f2f5',
  },
  header: {
    padding: 20,
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
    backgroundColor: '#fff',
  },
  logoContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  logo: {
    width: 40,
    height: 40,
    backgroundColor: '#3498db',
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
  },
  logoText: {
    color: '#fff',
    fontSize: 24,
    fontWeight: 'bold',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#2c3e50',
  },
  welcomeMessage: {
    fontSize: 16,
    color: '#3498db',
  },
  chatContainer: {
    flex: 1,
    padding: 15,
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  emptyStateText: {
    color: '#95a5a6',
    fontSize: 18,
    backgroundColor: '#f1f1f1',
    padding: 20,
    borderRadius: 8,
  },
  messagesList: {
    paddingBottom: 15,
  },
  messageContainer: {
    flexDirection: 'row',
    marginBottom: 16,
    alignItems: 'flex-start',
  },
  userMessage: {
    flexDirection: 'row-reverse',
  },
  messageAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    fontSize: 20,
  },
  userAvatar: {
    backgroundColor: '#e1f5fe',
    marginLeft: 12,
  },
  assistantAvatar: {
    backgroundColor: '#e8f5e9',
    marginRight: 12,
  },
  messageContent: {
    maxWidth: '70%',
    padding: 12,
    borderRadius: 18,
  },
  userContent: {
    backgroundColor: '#3498db',
    borderTopRightRadius: 4,
  },
  assistantContent: {
    backgroundColor: '#f1f1f1',
    borderTopLeftRadius: 4,
  },
  messageText: {
    lineHeight: 20,
    fontSize: 16,
  },
  userText: {
    color: '#fff',
  },
  assistantText: {
    color: '#333',
  },
  voiceControlContainer: {
    alignItems: 'center',
    marginBottom: 10,
  },
  inputContainer: {
    flexDirection: 'row',
    padding: 15,
    backgroundColor: '#fff',
    borderTopWidth: 1,
    borderTopColor: '#ddd',
  },
  input: {
    flex: 1,
    height: 48,
    backgroundColor: '#f9f9f9',
    borderRadius: 24,
    paddingHorizontal: 20,
    marginRight: 10,
    fontSize: 16,
  },
  button: {
    backgroundColor: '#3498db',
    borderRadius: 24,
    height: 48,
    width: 80,
    justifyContent: 'center',
    alignItems: 'center',
  },
  buttonDisabled: {
    backgroundColor: '#95a5a6',
  },
  buttonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
  },
});
