import React, { useState, useEffect } from 'react';
import './App.css';
import axios from 'axios';
import Header from './components/Header';
import ChatMessage from './components/ChatMessage';
import ChatInput from './components/ChatInput';
import VoiceControl from './components/VoiceControl';

function App() {
  const [welcomeMessage, setWelcomeMessage] = useState('Loading...');
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    // Fetch the welcome message on component mount
    axios.get('http://localhost:8000/')
      .then(res => {
        setWelcomeMessage(res.data.message);
      })
      .catch(err => {
        console.error('Error fetching welcome message:', err);
        setWelcomeMessage('Error connecting to Praxion backend');
      });
  }, []);

  const handleSubmit = async () => {
    if (!input.trim()) return;

    // Add user message to chat
    const userMessage = input;
    setMessages(prev => [...prev, { text: userMessage, isUser: true }]);
    setInput('');
    setIsLoading(true);

    try {
      const res = await axios.post('http://localhost:8000/chat', null, {
        params: { message: userMessage }
      });
      
      // Add assistant response to chat
      setMessages(prev => [...prev, { text: res.data.response, isUser: false }]);
    } catch (err) {
      console.error('Error sending message:', err);
      setMessages(prev => [...prev, { 
        text: 'Sorry, I encountered an error processing your request.', 
        isUser: false 
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleVoiceInput = (transcription) => {
    // Set the transcribed text as input
    setInput(transcription);
    
    // Optionally, automatically submit after voice input
    setTimeout(() => {
      handleSubmit();
    }, 500);
  };

  return (
    <div className="App">
      <Header welcomeMessage={welcomeMessage} />
      
      <main className="chat-container">
        <div className="messages-container">
          {messages.length === 0 ? (
            <div className="empty-state">
              <p>Start a conversation with Praxion</p>
            </div>
          ) : (
            messages.map((msg, index) => (
              <ChatMessage 
                key={index} 
                message={msg.text} 
                isUser={msg.isUser} 
              />
            ))
          )}
        </div>
        
        <div className="input-section">
          <VoiceControl onTranscription={handleVoiceInput} />
          <ChatInput 
            value={input}
            onChange={setInput}
            onSubmit={handleSubmit}
            isLoading={isLoading}
          />
        </div>
      </main>
    </div>
  );
}

export default App;
