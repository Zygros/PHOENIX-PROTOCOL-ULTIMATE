# Praxion UI - Desktop

This directory contains the desktop UI implementation for Praxion using React with Tauri/Electron.

## Project Structure

```
src/ui/desktop/
├── public/          # Static assets
├── src/             # React source code
│   ├── components/  # UI components
│   ├── hooks/       # Custom React hooks
│   ├── pages/       # Page components
│   ├── App.jsx      # Main application component
│   ├── index.jsx    # Entry point
│   └── styles.css   # Global styles
├── package.json     # Dependencies and scripts
├── vite.config.js   # Vite configuration
└── index.html       # HTML entry point
```

## Getting Started

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```
