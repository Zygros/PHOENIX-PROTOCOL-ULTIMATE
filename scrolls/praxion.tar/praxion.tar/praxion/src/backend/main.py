#!/usr/bin/env python3
"""
Praxion - Main Entry Point
A standalone AI companion based on the PRAX PRIME design
"""

import os
import logging
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import uvicorn

# Import Praxion modules
from .persona import PersonaEngine
from .memory import MemorySystem
from .voice import VoiceSystem
from .llm import LLMEngine

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("praxion")

# Initialize FastAPI app
app = FastAPI(
    title="Praxion API",
    description="Backend API for Praxion - Standalone AI Companion",
    version="0.1.0"
)

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, restrict this to your UI domains
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize core components
try:
    memory_system = MemorySystem()
    llm_engine = LLMEngine()
    voice_system = VoiceSystem()
    persona_engine = PersonaEngine(llm_engine, memory_system)
    
    logger.info("All core systems initialized successfully")
except Exception as e:
    logger.error(f"Error initializing core systems: {str(e)}")
    raise

# Define API routes
@app.get("/")
async def root():
    """Root endpoint returning a welcome message"""
    return {"message": "Hello, Praxion!"}

@app.get("/status")
async def status():
    """Return the status of all Praxion systems"""
    return {
        "status": "operational",
        "systems": {
            "memory": memory_system.status(),
            "llm": llm_engine.status(),
            "voice": voice_system.status(),
            "persona": persona_engine.status()
        }
    }

@app.post("/chat")
async def chat(message: str):
    """Process a text chat message and return a response"""
    try:
        response = persona_engine.process_message(message)
        return {"response": response}
    except Exception as e:
        logger.error(f"Error processing chat message: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/voice")
async def voice_input(audio_data: bytes):
    """Process voice input and return a text response"""
    try:
        text = voice_system.speech_to_text(audio_data)
        response = persona_engine.process_message(text)
        return {"text": text, "response": response}
    except Exception as e:
        logger.error(f"Error processing voice input: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# Mount static files for the UI
try:
    app.mount("/ui", StaticFiles(directory="../ui/desktop/dist"), name="ui")
except Exception as e:
    logger.warning(f"Could not mount UI files: {str(e)}")

def start_server():
    """Start the Praxion server"""
    logger.info("Starting Praxion server...")
    uvicorn.run(
        "praxion.src.backend.main:app",
        host="0.0.0.0",
        port=8000,
        reload=True
    )

if __name__ == "__main__":
    start_server()
