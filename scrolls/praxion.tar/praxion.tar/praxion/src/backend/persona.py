#!/usr/bin/env python3
"""
Praxion - Persona Engine
Manages the AI personality, reasoning, and response generation
"""

import logging
from typing import Dict, Any, List, Optional

logger = logging.getLogger("praxion.persona")

class PersonaEngine:
    """
    The PersonaEngine manages the AI personality, reasoning capabilities,
    and response generation for Praxion.
    """
    
    def __init__(self, llm_engine, memory_system):
        """
        Initialize the PersonaEngine with required dependencies
        
        Args:
            llm_engine: The LLM engine for text generation
            memory_system: The memory system for context and history
        """
        self.llm_engine = llm_engine
        self.memory_system = memory_system
        self.persona_config = self._load_persona_config()
        logger.info("PersonaEngine initialized")
    
    def _load_persona_config(self) -> Dict[str, Any]:
        """
        Load the persona configuration
        
        Returns:
            Dict containing persona configuration
        """
        # In a real implementation, this would load from a config file
        return {
            "name": "Praxion",
            "personality_traits": ["helpful", "knowledgeable", "friendly"],
            "communication_style": "conversational",
            "knowledge_domains": ["general", "science", "technology", "philosophy"],
            "reasoning_depth": "medium"
        }
    
    def process_message(self, message: str) -> str:
        """
        Process an incoming message and generate a response
        
        Args:
            message: The user's message text
            
        Returns:
            The generated response text
        """
        # 1. Retrieve relevant context from memory
        context = self.memory_system.get_relevant_context(message)
        
        # 2. Prepare prompt for LLM
        prompt = self._prepare_prompt(message, context)
        
        # 3. Generate response using LLM
        response = self.llm_engine.generate(prompt)
        
        # 4. Store interaction in memory
        self.memory_system.store_interaction(message, response)
        
        return response
    
    def _prepare_prompt(self, message: str, context: List[Dict[str, Any]]) -> str:
        """
        Prepare a prompt for the LLM based on the message and context
        
        Args:
            message: The user's message
            context: Relevant context from memory
            
        Returns:
            Formatted prompt for the LLM
        """
        # In a real implementation, this would construct a more sophisticated prompt
        system_prompt = f"""You are {self.persona_config['name']}, a helpful AI assistant.
Your personality is {', '.join(self.persona_config['personality_traits'])}.
You communicate in a {self.persona_config['communication_style']} style.
"""
        
        context_text = "\n".join([f"{item['timestamp']}: {item['content']}" for item in context])
        
        return f"{system_prompt}\n\nContext:\n{context_text}\n\nUser: {message}\n\nAssistant:"
    
    def status(self) -> Dict[str, Any]:
        """
        Get the current status of the PersonaEngine
        
        Returns:
            Dict containing status information
        """
        return {
            "status": "operational",
            "persona": self.persona_config["name"],
            "traits": self.persona_config["personality_traits"],
            "domains": self.persona_config["knowledge_domains"]
        }
