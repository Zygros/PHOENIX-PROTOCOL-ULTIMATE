#!/usr/bin/env python3
"""
Praxion - Backend Package Initialization
"""

import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

# Import core modules to make them available
from .main import app, start_server
from .persona import PersonaEngine
from .memory import MemorySystem
from .voice import VoiceSystem
from .llm import LLMEngine

__version__ = "0.1.0"
