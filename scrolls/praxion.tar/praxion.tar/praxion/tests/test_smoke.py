#!/usr/bin/env python3
import pytest
from fastapi.testclient import TestClient
from src.backend.main import app

client = TestClient(app)

def test_root_endpoint():
    """Test that the root endpoint returns 'Hello, Praxion!'"""
    response = client.get("/")
    assert response.status_code == 200
    assert response.json() == {"message": "Hello, Praxion!"}

def test_status_endpoint():
    """Test that the status endpoint returns operational status"""
    response = client.get("/status")
    assert response.status_code == 200
    assert response.json()["status"] == "operational"
    
    # Check that all systems are reported
    systems = response.json()["systems"]
    assert "memory" in systems
    assert "llm" in systems
    assert "voice" in systems
    assert "persona" in systems
