#!/usr/bin/env python3
"""
Praxion - Proof of Life Test
Run this script to verify that Praxion is working correctly
"""

import sys
import os
import requests
import time
import json

def print_header():
    print("\n" + "="*50)
    print("PRAXION - PROOF OF LIFE TEST")
    print("="*50)

def check_backend():
    print("\nChecking backend connection...")
    try:
        response = requests.get("http://localhost:8000/")
        if response.status_code == 200:
            message = response.json().get("message", "")
            if "Hello, Praxion" in message:
                print("✅ Backend is running and returned:", message)
                return True
            else:
                print("❌ Backend is running but returned unexpected message:", message)
                return False
        else:
            print(f"❌ Backend returned status code: {response.status_code}")
            return False
    except requests.exceptions.ConnectionError:
        print("❌ Could not connect to backend. Is it running on http://localhost:8000?")
        return False

def test_chat():
    print("\nTesting chat functionality...")
    try:
        response = requests.post("http://localhost:8000/chat", params={"message": "Hello, Praxion!"})
        if response.status_code == 200:
            print("✅ Chat endpoint responded successfully")
            print(f"Response: {response.json().get('response', '')}")
            return True
        else:
            print(f"❌ Chat endpoint returned status code: {response.status_code}")
            return False
    except requests.exceptions.ConnectionError:
        print("❌ Could not connect to backend. Is it running on http://localhost:8000?")
        return False

def check_resources():
    print("\nChecking resource files...")
    
    resource_paths = [
        "resources/models/llm/model_info.json",
        "resources/models/voice/whisper_tiny.json",
        "resources/models/voice/tts_mini.json",
        "resources/memory/conversation_history.json"
    ]
    
    all_present = True
    for path in resource_paths:
        if os.path.exists(path):
            print(f"✅ Found {path}")
        else:
            print(f"❌ Missing {path}")
            all_present = False
    
    return all_present

def main():
    print_header()
    
    print("\nThis script will verify that Praxion is working correctly.")
    print("Make sure the backend is running before continuing.")
    
    input("\nPress Enter to begin the test...")
    
    backend_ok = check_backend()
    chat_ok = test_chat() if backend_ok else False
    resources_ok = check_resources()
    
    print("\n" + "="*50)
    print("TEST RESULTS")
    print("="*50)
    print(f"Backend Connection: {'✅ PASS' if backend_ok else '❌ FAIL'}")
    print(f"Chat Functionality: {'✅ PASS' if chat_ok else '❌ FAIL'}")
    print(f"Resource Files:     {'✅ PASS' if resources_ok else '❌ FAIL'}")
    
    if backend_ok and chat_ok and resources_ok:
        print("\n🎉 All tests passed! Praxion is working correctly.")
        print("\nNext steps:")
        print("1. Try the desktop UI: cd src/ui/desktop && npm install && npm run dev")
        print("2. Try the mobile UI: cd src/ui/mobile && yarn install && expo start")
    else:
        print("\n⚠️ Some tests failed. Please check the output above for details.")
        print("\nTroubleshooting tips:")
        print("1. Make sure the backend is running: ./scripts/run.sh backend")
        print("2. Check if resources are set up: ./scripts/setup_resources.sh")
        print("3. Verify your Python environment: python -m venv .venv && source .venv/bin/activate && pip install -r requirements.txt")

if __name__ == "__main__":
    main()
