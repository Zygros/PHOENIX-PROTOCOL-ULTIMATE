#!/bin/bash
# Make scripts executable
chmod +x scripts/run.sh
chmod +x scripts/setup_resources.sh

# Set up resources for offline operation
./scripts/setup_resources.sh

# Create a simple startup script for the proof of life
cat > start_praxion.sh << EOL
#!/bin/bash
echo "Starting Praxion - Standalone AI Companion"
echo "----------------------------------------"
echo "Setting up environment..."

# Check if virtual environment exists
if [ ! -d ".venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv .venv
fi

# Activate virtual environment
source .venv/bin/activate

# Install dependencies
echo "Installing dependencies..."
pip install -r requirements.txt

# Start the backend
echo "Starting Praxion backend..."
echo "Open http://localhost:8000 in your browser to see the API"
echo "Or run the desktop UI with: cd src/ui/desktop && npm install && npm run dev"
echo ""
echo "Press Ctrl+C to stop the server"
uvicorn src.backend.main:app --reload
EOL

# Make the startup script executable
chmod +x start_praxion.sh

echo "Praxion setup complete! Run ./start_praxion.sh to start the application."
