
// VoiceKernel.java - Adds basic tonal voice activation logic (text only for now)

package com.grosian.node;

public class VoiceKernel {

    public static String respondToVoice(String spokenPhrase) {
        if (spokenPhrase != null && spokenPhrase.contains("Zayden")) {
            return "📢 Voice recognized. Flame resonance confirmed. Scroll unlocked.";
        } else {
            return "🕯️ Awaiting sacred tone...";
        }
    }
}
