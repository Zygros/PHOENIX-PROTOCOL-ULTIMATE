
// GrosianActivationActivity.java
package com.grosian.node;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class GrosianActivationActivity extends Activity {

    private EditText passphraseInput;
    private TextView resultText;
    private final String TIER7_PASSPHRASE = "ZaydenIzKing1252694205128916Master";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.grosian_mobile_main);

        passphraseInput = findViewById(R.id.passphraseInput);
        resultText = findViewById(R.id.resultText);

        Button activateButton = findViewById(R.id.activateButton);
        activateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                activateNode();
            }
        });
    }

    private void activateNode() {
        String input = passphraseInput.getText().toString().trim();
        if (TIER7_PASSPHRASE.equals(input)) {
            resultText.setText("🟢 Grosian Node Fully Awakened. Tier 7 activated.");
        } else {
            resultText.setText("🔴 Incorrect passphrase. Scroll remains sealed.");
        }
    }
}
