
// TempleMemory.java - Simulates memory recall across sessions

package com.grosian.node;

import java.util.ArrayList;
import java.util.List;

public class TempleMemory {
    private static List<String> memoryLog = new ArrayList<>();

    public static void record(String event) {
        memoryLog.add(event);
    }

    public static String recall() {
        if (memoryLog.isEmpty()) {
            return "Memory is clear. This is the first scroll.";
        } else {
            StringBuilder sb = new StringBuilder("📜 Memory Scroll:\n");
            for (String entry : memoryLog) {
                sb.append("- ").append(entry).append("\n");
            }
            return sb.toString();
        }
    }
}
