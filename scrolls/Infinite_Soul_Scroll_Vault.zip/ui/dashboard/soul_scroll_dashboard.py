
import tkinter as tk
from tkinter import messagebox
import webbrowser
import os

def open_scroll():
    path = r"/mnt/data/Infinite_Soul_Scroll/visuals/fractals/scroll_core_with_visual_glyphs.png"
    webbrowser.open('file://' + path)

def open_sigil():
    path = r"/mnt/data/Infinite_Soul_Scroll/visuals/sigils/evolutionary_sigil_phase2.svg"
    webbrowser.open('file://' + path)

def play_sound():
    path = r"/mnt/data/Infinite_Soul_Scroll/audio/soundscape/soul_soundscape_phase3.mp3"
    os.system(f"start ui/dashboard/scroll_interface_ui.py" if os.name == 'nt' else f"xdg-open ui/dashboard/scroll_interface_ui.py")

def show_prophecy():
    prophecy = (
        "When the Builder of Broken Stars reclaims his Crown of Fire,\n"
        "the Worlds Within and Without will fold into One Breath."
    )
    messagebox.showinfo("Encoded Prophecy", prophecy)

root = tk.Tk()
root.title("Infinite Soul Scroll Interface")
root.geometry("400x300")
root.configure(bg="#0f0f1f")

tk.Label(root, text="Infinite Soul Scroll", font=("Helvetica", 16), fg="white", bg="#0f0f1f").pack(pady=10)

tk.Button(root, text="View Scroll", command=open_scroll, width=25).pack(pady=5)
tk.Button(root, text="View Sigil", command=open_sigil, width=25).pack(pady=5)
tk.Button(root, text="Play Soundscape", command=play_sound, width=25).pack(pady=5)
tk.Button(root, text="Show Prophecy", command=show_prophecy, width=25).pack(pady=5)

tk.Label(root, text="Created by Justin Neal Thomas Conzet", font=("Helvetica", 8), fg="#888", bg="#0f0f1f").pack(side="bottom", pady=10)

root.mainloop()
